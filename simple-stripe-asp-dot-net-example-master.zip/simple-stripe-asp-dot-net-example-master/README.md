## A Simple Stripe.Net Payment with ASP.NET MVC


A simple ASP.NET MVC integrated with Stripe's pay button.


## Author
**Chuen Hing Lee**

+ [http://twitter.com/ch_lee99](http://twitter.com/ch_lee99)