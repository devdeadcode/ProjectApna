﻿using eOne.Common.DataConnectors;

namespace eOne.Common.Connectors.Trello.Models
{
    public class TrelloAction : DataConnectorEntityModel
    {



    }
}
