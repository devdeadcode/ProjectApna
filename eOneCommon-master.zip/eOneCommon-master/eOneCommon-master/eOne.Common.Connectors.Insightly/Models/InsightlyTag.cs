﻿using eOne.Common.DataConnectors;

namespace eOne.Common.Connectors.Insightly.Models
{
    public class InsightlyTag : DataConnectorEntityModel
    {

        public string TAG_NAME { get; set; }

    }
}
