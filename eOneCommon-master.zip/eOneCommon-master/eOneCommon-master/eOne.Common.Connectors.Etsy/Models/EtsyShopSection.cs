﻿namespace eOne.Common.Connectors.Etsy.Models
{
    public class EtsyShopSection
    {

        public int shop_section_id { get; set; }
        public string title { get; set; }
        public int rank { get; set; }
        public int user_id { get; set; }
        public int active_listing_count { get; set; }

    }
}