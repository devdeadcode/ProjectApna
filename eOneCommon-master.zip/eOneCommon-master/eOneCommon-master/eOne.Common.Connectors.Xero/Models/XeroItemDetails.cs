﻿namespace eOne.Common.Connectors.Xero.Models
{
    public class XeroItemDetails
    {

        public decimal UnitPrice { get; set; }
        public string AccountCode { get; set; }

    }
}