﻿namespace eOne.Common.Connectors.Xero.Models
{
    public class XeroOrganisationPaymentTerms
    {

        public XeroPaymentTerms Bills { get; set; }
        public XeroPaymentTerms Sales { get; set; }

    }
}
