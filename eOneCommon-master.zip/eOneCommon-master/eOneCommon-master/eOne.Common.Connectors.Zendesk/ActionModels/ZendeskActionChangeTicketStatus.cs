﻿namespace eOne.Common.Connectors.Zendesk.ActionModels
{
    public class ZendeskActionChangeTicketStatus
    {

        public string id { get; set; }
        public string status { get; set; }
        
    }
}
