﻿using eOne.Common.DataConnectors;

namespace eOne.Common.Connectors.Zendesk.Models
{
    public class ZendeskTicketViaSource : DataConnectorEntityModel
    {

        public string rel { get; set; }
        
     //"to": { },
     //"from": {
     //  "id": 22472716,
     //  "title": "Assign to first responder"

    }
}
