﻿using System.Collections.Generic;

namespace eOne.Common.Connectors.ZenPayroll.Models
{
    public class ZenPayrollPayPeriodEligibleEmployee
    {

        public int id { get; set; }
        public List<int> job_ids { get; set; }

    }
}
