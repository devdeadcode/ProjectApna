﻿namespace eOne.Common.Connectors.ZenPayroll.Models
{
    public class ZenPayrollCompanyCompensation
    {

        public string name { get; set; }
        public decimal multiple { get; set; }

    }
}
