﻿using System;

namespace eOne.Common.Connectors.ZenPayroll.Models
{
    public class ZenPayrollPayPeriodPayroll
    {

        public DateTime payroll_deadline { get; set; }
        public bool processed { get; set; }

    }
}