﻿using eOne.Common.DataConnectors;

namespace eOne.Common.Connectors.Shopify.Models
{
    public class ShopifyRecurringInvoice : DataConnectorEntityModel
    {
    }
}
