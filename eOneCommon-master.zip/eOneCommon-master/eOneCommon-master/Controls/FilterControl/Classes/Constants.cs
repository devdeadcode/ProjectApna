﻿namespace FilterControl.Classes
{
    public class Constants
    {

        

    }
}
