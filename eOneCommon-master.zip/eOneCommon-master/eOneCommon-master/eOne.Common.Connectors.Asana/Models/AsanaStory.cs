﻿namespace eOne.Common.Connectors.Asana.Models
{
    public class AsanaStory
    {
    }
}
