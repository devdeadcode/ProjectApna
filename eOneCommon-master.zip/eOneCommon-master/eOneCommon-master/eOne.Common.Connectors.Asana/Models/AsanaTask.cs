﻿namespace eOne.Common.Connectors.Asana.Models
{
    public class AsanaTask
    {



    }
}
