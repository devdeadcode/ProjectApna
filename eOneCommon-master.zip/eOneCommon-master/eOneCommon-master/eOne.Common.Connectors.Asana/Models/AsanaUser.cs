﻿namespace eOne.Common.Connectors.Asana.Models
{
    public class AsanaUser
    {

        public string email { get; set; }
        public int id { get; set; }
        public string name { get; set; }

    }
}
