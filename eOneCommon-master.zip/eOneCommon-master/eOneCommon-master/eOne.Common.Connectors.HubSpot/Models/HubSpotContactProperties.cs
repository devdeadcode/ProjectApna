﻿namespace eOne.Common.Connectors.HubSpot.Models
{
    public class HubSpotContactProperties
    {



    }
}
