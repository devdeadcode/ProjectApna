﻿namespace eOne.Common.Connectors.HubSpot.Models
{
    public class HubSpotContact
    {

        public int addedAt { get; set; }
        public int vid { get; set; }

    }
}

//{
//"addedAt":1405347851360,
//"vid":154835,
//"canonical-vid":154835,
//"merged-vids":[],
//"portal-id":62515,
//"is-contact":true,
//"profile-token":"AO_T-mMEydfM2wDgyfVJVRZVCgbcBsBjMyafDWjeGqhYZVEjxhwJV_4PJxr44QR3Qj4Pa7ioZcammyaiE9eauoRVAk0MG43IgR6DYHdgZ82Ys-CEg6KATgAIihmeske7AyZpuxnh0LX4",
//"profile-url":"https://app.hubspot.com/contacts/62515/lists/public/contact/_AO_T-mMEydfM2wDgyfVJVRZVCgbcBsBjMyafDWjeGqhYZVEjxhwJV_4PJxr44QR3Qj4Pa7ioZcammyaiE9eauoRVAk0MG43IgR6DYHdgZ82Ys-CEg6KATgAIihmeske7AyZpuxnh0LX4/",
//"properties":
//{
//"firstname":{"value":"Adrian Updated"},
//"lastmodifieddate":{"value":"1438158853363"},
//"company":{"value":"Derp Durr Hurr"},
//"lastname":{"value":"Mott"}},
//"form-submissions":[{"conversion-id":"b18f9fd8-b8d3-49e5-898a-ac301fac93e9",
//"timestamp":1405347851180,"form-id":"b844ad5e-32bd-41e1-b0e6-ed990c5f3d1b",
//"portal-id":62515,"page-url":"http://demo.hubapi.com/your-stunning-headline-30",
//"page-title":"Your stunning headline!","page-id":"324527","title":"My New Form","meta-data":[]}],
//"identity-profiles":[{"vid":154835,"saved-at-timestamp":1434741580156,"deleted-changed-timestamp":0,
//"identities":[{"type":"LEAD_GUID","value":"c8f20860-d3d6-4b57-b092-86a07cebdcbc","timestamp":1405347851237},
//{"type":"EMAIL","value":"bob@example.com","timestamp":1434741580120}]}],"merge-audits":[]}
