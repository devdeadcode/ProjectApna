﻿namespace eOne.Common.Connectors.Formstack.Models
{
    public class FormstackSubmissionData
    {

        public int field { get; set; }
        public string value { get; set; }

    }
}
