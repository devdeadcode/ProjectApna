﻿namespace eOne.Common.Connectors.Formstack.Models
{
    public class FormstackFieldOption
    {

        public string label { get; set; }
        public string value { get; set; }

    }
}
