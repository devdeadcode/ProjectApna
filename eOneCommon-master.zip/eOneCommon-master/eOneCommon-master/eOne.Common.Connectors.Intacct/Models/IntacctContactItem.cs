﻿namespace eOne.Common.Connectors.Intacct.Models
{
    public class IntacctContactItem
    {

        public string category { get; set; }
        public string contactname { get; set; }

    }
}