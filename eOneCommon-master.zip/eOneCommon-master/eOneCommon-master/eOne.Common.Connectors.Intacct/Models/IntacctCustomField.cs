﻿namespace eOne.Common.Connectors.Intacct.Models
{
    public class IntacctCustomField
    {

        public string customfieldname { get; set; }
        public string customfieldvalue { get; set; }

    }
}