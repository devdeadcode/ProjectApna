﻿namespace eOne.Common.Connectors.Intacct.Models
{
    public class IntacctProjectResource
    {

        public string employeeid { get; set; }
        public string itemid { get; set; }
        public string resourcedescription { get; set; }
        public decimal billingrate { get; set; }

    }
}