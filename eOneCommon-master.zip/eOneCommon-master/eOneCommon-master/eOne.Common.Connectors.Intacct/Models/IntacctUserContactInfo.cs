﻿namespace eOne.Common.Connectors.Intacct.Models
{
    public class IntacctUserContactInfo
    {

        public string LASTNAME { get; set; }
        public string FIRSTNAME { get; set; }
        public string EMAIL1 { get; set; }
        public string CONTACTNAME { get; set; }

    }
}
