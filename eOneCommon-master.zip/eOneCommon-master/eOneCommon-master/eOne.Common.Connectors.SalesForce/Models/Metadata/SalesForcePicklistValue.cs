﻿namespace eOne.Common.Connectors.SalesForce.Models.Metadata
{
    public class SalesForcePicklistValue
    {

        public bool active { get; set; }
        public bool defaultValue { get; set; }
        public string label { get; set; }
        public string validFor { get; set; }
        public string value { get; set; }

    }
}