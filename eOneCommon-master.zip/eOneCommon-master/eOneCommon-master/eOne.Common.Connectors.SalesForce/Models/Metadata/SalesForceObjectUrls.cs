﻿namespace eOne.Common.Connectors.SalesForce.Models.Metadata
{
    public class SalesForceObjectUrls
    {

        public string sobject { get; set; }
        public string describe { get; set; }
        public string rowTemplate { get; set; }
        public string uiEditTemplate { get; set; }
        public string uiDetailTemplate { get; set; }
        public string uiNewRecord { get; set; }

    }
}