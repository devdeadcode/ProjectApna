﻿namespace eOne.Common.Connectors.SalesForce.Models
{
    public class SalesForceOpportunity : SalesForceEntity
    {
    }
}
