﻿namespace eOne.Common.Connectors.SalesForce.Models
{
    public class SalesForceSolution : SalesForceEntity
    {
    }
}
