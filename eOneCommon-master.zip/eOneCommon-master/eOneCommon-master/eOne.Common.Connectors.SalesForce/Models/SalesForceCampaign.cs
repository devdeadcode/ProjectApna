﻿namespace eOne.Common.Connectors.SalesForce.Models
{
    public class SalesForceCampaign : SalesForceEntity
    {
    }
}
