﻿using eOne.Common.DataConnectors;

namespace eOne.Common.Connectors.GitHub.Models
{
    public class GitHubPermission : DataConnectorEntityModel
    {
    }
}
