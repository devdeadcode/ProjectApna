﻿namespace eOne.Common.Connectors.Paypal.Models
{
    public class PaypalCurrency
    {

        public string currency { get; set; }
        public decimal value { get; set; }

    }
}