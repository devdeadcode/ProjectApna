﻿namespace eOne.Common.Connectors.Paypal.Models
{
    public class PaypalAmount
    {

        public decimal total { get; set; }
        public string currency { get; set; }

    }
}
