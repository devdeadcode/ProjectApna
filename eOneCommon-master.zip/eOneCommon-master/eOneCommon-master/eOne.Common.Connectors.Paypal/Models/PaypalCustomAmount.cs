﻿namespace eOne.Common.Connectors.Paypal.Models
{
    public class PaypalCustomAmount
    {

        public string label { get; set; }
        public PaypalCurrency amount { get; set; }

    }
}