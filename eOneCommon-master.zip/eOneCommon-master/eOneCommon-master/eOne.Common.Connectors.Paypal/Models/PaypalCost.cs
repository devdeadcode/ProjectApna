﻿namespace eOne.Common.Connectors.Paypal.Models
{
    public class PaypalCost
    {

        public decimal percent { get; set; }
        public PaypalCurrency amount { get; set; }

    }
}